import React, { useState } from 'react';
import { useAuth } from '@/hooks/useAuth';
import Header from '@/components/layout/Header';
import DashboardStats from '@/components/dashboard/DashboardStats';
import SalesChart from '@/components/dashboard/SalesChart';
import SalesForm from '@/components/sales/SalesForm';
import SalesList from '@/components/sales/SalesList';
import UserManagement from '@/components/admin/UserManagement';
import PDFExport from '@/components/reports/PDFExport';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BarChart3, Plus, List, Users, Settings } from 'lucide-react';

const Dashboard: React.FC = () => {
  const { userRole } = useAuth();
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  const handleSaleAdded = () => {
    setRefreshTrigger(prev => prev + 1);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      
      <main className="container mx-auto px-6 py-6">
        <div className="space-y-6">
          {/* Stats Overview */}
          <DashboardStats />

          {/* Main Content Tabs */}
          <Tabs defaultValue="overview" className="space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <TabsList className="grid w-full sm:w-auto grid-cols-2 sm:grid-cols-4 lg:grid-cols-5">
                <TabsTrigger value="overview" className="flex items-center gap-2">
                  <BarChart3 className="h-4 w-4" />
                  <span className="hidden sm:inline">Overview</span>
                </TabsTrigger>
                <TabsTrigger value="add-sale" className="flex items-center gap-2">
                  <Plus className="h-4 w-4" />
                  <span className="hidden sm:inline">Add Sale</span>
                </TabsTrigger>
                <TabsTrigger value="sales-list" className="flex items-center gap-2">
                  <List className="h-4 w-4" />
                  <span className="hidden sm:inline">Sales</span>
                </TabsTrigger>
                {userRole === 'admin' && (
                  <>
                    <TabsTrigger value="users" className="flex items-center gap-2">
                      <Users className="h-4 w-4" />
                      <span className="hidden sm:inline">Users</span>
                    </TabsTrigger>
                    <TabsTrigger value="reports" className="flex items-center gap-2">
                      <Settings className="h-4 w-4" />
                      <span className="hidden sm:inline">Reports</span>
                    </TabsTrigger>
                  </>
                )}
              </TabsList>
              
              {userRole === 'admin' && <PDFExport />}
            </div>

            <TabsContent value="overview" className="space-y-6">
              <SalesChart />
              <SalesList refreshTrigger={refreshTrigger} showFilters={userRole === 'admin'} />
            </TabsContent>

            <TabsContent value="add-sale">
              <SalesForm onSaleAdded={handleSaleAdded} />
            </TabsContent>

            <TabsContent value="sales-list">
              <SalesList refreshTrigger={refreshTrigger} showFilters={userRole === 'admin'} />
            </TabsContent>

            {userRole === 'admin' && (
              <>
                <TabsContent value="users">
                  <UserManagement />
                </TabsContent>

                <TabsContent value="reports">
                  <div className="space-y-6">
                    <SalesChart />
                    <PDFExport />
                  </div>
                </TabsContent>
              </>
            )}
          </Tabs>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;