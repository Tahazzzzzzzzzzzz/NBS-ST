import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { supabase } from '@/integrations/supabase/client';
import { DollarSign, TrendingUp, Users, Calendar } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';

interface Stats {
  totalSales: number;
  salesCount: number;
  avgSaleAmount: number;
  todaySales: number;
  thisWeekSales: number;
  thisMonthSales: number;
}

const DashboardStats: React.FC = () => {
  const { userRole, user } = useAuth();
  const [stats, setStats] = useState<Stats>({
    totalSales: 0,
    salesCount: 0,
    avgSaleAmount: 0,
    todaySales: 0,
    thisWeekSales: 0,
    thisMonthSales: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, [userRole, user]);

  const fetchStats = async () => {
    try {
      let baseQuery = supabase.from('sales').select('amount, created_at');
      
      // If salesman, filter to their sales only
      if (userRole === 'salesman' && user) {
        baseQuery = baseQuery.eq('salesman_id', user.id);
      }

      const { data: sales, error } = await baseQuery;

      if (error) throw error;

      const now = new Date();
      const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
      const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
      const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);

      const totalSales = sales?.reduce((sum, sale) => sum + sale.amount, 0) || 0;
      const salesCount = sales?.length || 0;
      const avgSaleAmount = salesCount > 0 ? totalSales / salesCount : 0;

      const todaySales = sales?.filter(sale => 
        new Date(sale.created_at) >= today
      ).reduce((sum, sale) => sum + sale.amount, 0) || 0;

      const thisWeekSales = sales?.filter(sale => 
        new Date(sale.created_at) >= weekAgo
      ).reduce((sum, sale) => sum + sale.amount, 0) || 0;

      const thisMonthSales = sales?.filter(sale => 
        new Date(sale.created_at) >= monthStart
      ).reduce((sum, sale) => sum + sale.amount, 0) || 0;

      setStats({
        totalSales,
        salesCount,
        avgSaleAmount,
        todaySales,
        thisWeekSales,
        thisMonthSales,
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const StatCard: React.FC<{ title: string; value: string; icon: React.ReactNode; description?: string }> = ({ title, value, icon, description }) => (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        {description && (
          <p className="text-xs text-muted-foreground">{description}</p>
        )}
      </CardContent>
    </Card>
  );

  if (loading) {
    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <Card key={i}>
            <CardContent className="p-6">
              <div className="animate-pulse h-16"></div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <StatCard
        title="Total Sales"
        value={`$${stats.totalSales.toFixed(2)}`}
        icon={<DollarSign className="h-4 w-4 text-muted-foreground" />}
        description={`${stats.salesCount} total transactions`}
      />
      
      <StatCard
        title="Today's Sales"
        value={`$${stats.todaySales.toFixed(2)}`}
        icon={<Calendar className="h-4 w-4 text-muted-foreground" />}
        description="Sales from today"
      />
      
      <StatCard
        title="This Week"
        value={`$${stats.thisWeekSales.toFixed(2)}`}
        icon={<TrendingUp className="h-4 w-4 text-muted-foreground" />}
        description="Last 7 days"
      />
      
      <StatCard
        title="Average Sale"
        value={`$${stats.avgSaleAmount.toFixed(2)}`}
        icon={<Users className="h-4 w-4 text-muted-foreground" />}
        description="Per transaction"
      />
    </div>
  );
};

export default DashboardStats;