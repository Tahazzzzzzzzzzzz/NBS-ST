import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { format } from 'date-fns';
import { Search, Calendar, Download, Eye, Trash2, Edit } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface Sale {
  id: string;
  customer_name: string;
  product_service: string;
  amount: number;
  notes: string;
  created_at: string;
  profiles: {
    full_name: string;
  };
}

interface Profile {
  id: string;
  full_name: string;
}

interface SalesListProps {
  refreshTrigger?: number;
  showFilters?: boolean;
}

const SalesList: React.FC<SalesListProps> = ({ refreshTrigger, showFilters = true }) => {
  const { userRole, user } = useAuth();
  const { toast } = useToast();
  const [sales, setSales] = useState<Sale[]>([]);
  const [salesmen, setSalesmen] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedSalesman, setSelectedSalesman] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState<string>('all');

  useEffect(() => {
    fetchSales();
    if (userRole === 'admin') {
      fetchSalesmen();
    }
  }, [userRole, refreshTrigger]);

  useEffect(() => {
    // Set up real-time subscription
    const channel = supabase
      .channel('sales-changes')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'sales'
        },
        () => {
          fetchSales();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  const fetchSales = async () => {
    try {
      let query = supabase
        .from('sales')
        .select(`
          *,
          profiles (full_name)
        `)
        .order('created_at', { ascending: false });

      // If salesman, only show their sales
      if (userRole === 'salesman') {
        query = query.eq('salesman_id', user?.id);
      }

      const { data, error } = await query;

      if (error) throw error;
      setSales(data || []);
    } catch (error: any) {
      toast({
        title: "Error",
        description: "Failed to fetch sales data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchSalesmen = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select(`
          id,
          full_name,
          user_roles (role)
        `);

      if (error) throw error;

      const salesmenProfiles = data?.filter(profile => 
        profile.user_roles?.some((role: any) => role.role === 'salesman')
      ) || [];

      setSalesmen(salesmenProfiles);
    } catch (error) {
      console.error('Error fetching salesmen:', error);
    }
  };

  const handleDeleteSale = async (saleId: string) => {
    if (!confirm('Are you sure you want to delete this sale?')) return;

    try {
      const { error } = await supabase
        .from('sales')
        .delete()
        .eq('id', saleId);

      if (error) throw error;

      toast({
        title: "Sale Deleted",
        description: "Sale has been successfully deleted.",
      });

      fetchSales();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const filteredSales = sales.filter(sale => {
    const matchesSearch = 
      sale.customer_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sale.product_service.toLowerCase().includes(searchTerm.toLowerCase()) ||
      sale.profiles.full_name.toLowerCase().includes(searchTerm.toLowerCase());

    const matchesSalesman = selectedSalesman === 'all' || sale.profiles.full_name === selectedSalesman;

    const saleDate = new Date(sale.created_at);
    const today = new Date();
    const matchesDate = 
      dateFilter === 'all' ||
      (dateFilter === 'today' && saleDate.toDateString() === today.toDateString()) ||
      (dateFilter === 'week' && (today.getTime() - saleDate.getTime()) <= 7 * 24 * 60 * 60 * 1000) ||
      (dateFilter === 'month' && saleDate.getMonth() === today.getMonth() && saleDate.getFullYear() === today.getFullYear());

    return matchesSearch && matchesSalesman && matchesDate;
  });

  const totalAmount = filteredSales.reduce((sum, sale) => sum + sale.amount, 0);

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="text-center">Loading sales...</div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <CardTitle>Sales Records</CardTitle>
          <Badge variant="secondary" className="text-lg font-semibold">
            Total: ${totalAmount.toFixed(2)}
          </Badge>
        </div>

        {showFilters && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search sales..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            {userRole === 'admin' && (
              <Select value={selectedSalesman} onValueChange={setSelectedSalesman}>
                <SelectTrigger>
                  <SelectValue placeholder="Filter by salesman" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Salesmen</SelectItem>
                  {salesmen.map((salesman) => (
                    <SelectItem key={salesman.id} value={salesman.full_name}>
                      {salesman.full_name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}

            <Select value={dateFilter} onValueChange={setDateFilter}>
              <SelectTrigger>
                <Calendar className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Filter by date" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Time</SelectItem>
                <SelectItem value="today">Today</SelectItem>
                <SelectItem value="week">This Week</SelectItem>
                <SelectItem value="month">This Month</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )}
      </CardHeader>

      <CardContent>
        {filteredSales.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No sales records found.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Customer</TableHead>
                  <TableHead>Product/Service</TableHead>
                  <TableHead>Amount</TableHead>
                  {userRole === 'admin' && <TableHead>Salesman</TableHead>}
                  <TableHead>Notes</TableHead>
                  {userRole === 'admin' && <TableHead>Actions</TableHead>}
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredSales.map((sale) => (
                  <TableRow key={sale.id}>
                    <TableCell>
                      {format(new Date(sale.created_at), 'MMM dd, yyyy HH:mm')}
                    </TableCell>
                    <TableCell className="font-medium">{sale.customer_name}</TableCell>
                    <TableCell>{sale.product_service}</TableCell>
                    <TableCell className="font-semibold text-primary">
                      ${sale.amount.toFixed(2)}
                    </TableCell>
                    {userRole === 'admin' && (
                      <TableCell>{sale.profiles.full_name}</TableCell>
                    )}
                    <TableCell className="max-w-xs truncate">
                      {sale.notes || '-'}
                    </TableCell>
                    {userRole === 'admin' && (
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button
                            variant="destructive"
                            size="sm"
                            onClick={() => handleDeleteSale(sale.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    )}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default SalesList;