import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import { Loader2, Plus } from 'lucide-react';

interface Profile {
  id: string;
  full_name: string;
  email: string;
}

interface SalesFormProps {
  onSaleAdded?: () => void;
}

const SalesForm: React.FC<SalesFormProps> = ({ onSaleAdded }) => {
  const { user, userRole } = useAuth();
  const { toast } = useToast();
  const [isLoading, setIsLoading] = useState(false);
  const [salesmen, setSalesmen] = useState<Profile[]>([]);
  
  const [formData, setFormData] = useState({
    customer_name: '',
    product_service: '',
    amount: '',
    salesman_id: user?.id || '',
    notes: '',
  });

  useEffect(() => {
    if (userRole === 'admin') {
      fetchSalesmen();
    }
  }, [userRole]);

  const fetchSalesmen = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select(`
          id,
          full_name,
          email,
          user_roles (role)
        `);

      if (error) throw error;

      // Filter profiles that have salesman role
      const salesmenProfiles = data?.filter(profile => 
        profile.user_roles?.some((role: any) => role.role === 'salesman')
      ) || [];

      setSalesmen(salesmenProfiles);
    } catch (error) {
      console.error('Error fetching salesmen:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const salesData = {
        customer_name: formData.customer_name,
        product_service: formData.product_service,
        amount: parseFloat(formData.amount),
        salesman_id: formData.salesman_id,
        notes: formData.notes || null,
      };

      const { error } = await supabase
        .from('sales')
        .insert([salesData]);

      if (error) throw error;

      toast({
        title: "Sale Added",
        description: "Sale has been successfully recorded.",
      });

      // Reset form
      setFormData({
        customer_name: '',
        product_service: '',
        amount: '',
        salesman_id: user?.id || '',
        notes: '',
      });

      if (onSaleAdded) {
        onSaleAdded();
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Plus className="h-5 w-5 mr-2" />
          Add New Sale
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="customer_name">Customer Name</Label>
              <Input
                id="customer_name"
                value={formData.customer_name}
                onChange={(e) => setFormData({ ...formData, customer_name: e.target.value })}
                placeholder="Enter customer name"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="product_service">Product/Service</Label>
              <Input
                id="product_service"
                value={formData.product_service}
                onChange={(e) => setFormData({ ...formData, product_service: e.target.value })}
                placeholder="Enter product or service"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="amount">Amount ($)</Label>
              <Input
                id="amount"
                type="number"
                step="0.01"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                placeholder="0.00"
                required
              />
            </div>

            {userRole === 'admin' && (
              <div className="space-y-2">
                <Label htmlFor="salesman_id">Salesman</Label>
                <Select
                  value={formData.salesman_id}
                  onValueChange={(value) => setFormData({ ...formData, salesman_id: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select salesman" />
                  </SelectTrigger>
                  <SelectContent>
                    {salesmen.map((salesman) => (
                      <SelectItem key={salesman.id} value={salesman.id}>
                        {salesman.full_name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Notes (Optional)</Label>
            <Textarea
              id="notes"
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              placeholder="Additional notes about this sale"
              rows={3}
            />
          </div>

          <Button type="submit" className="w-full" disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Adding Sale...
              </>
            ) : (
              'Add Sale'
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default SalesForm;