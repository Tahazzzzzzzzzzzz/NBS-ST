import React from 'react';
import { Button } from '@/components/ui/button';
import { Download } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';
import { useToast } from '@/hooks/use-toast';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';
import { format } from 'date-fns';

interface Sale {
  id: string;
  customer_name: string;
  product_service: string;
  amount: number;
  notes: string;
  created_at: string;
  profiles: {
    full_name: string;
  };
}

const PDFExport: React.FC = () => {
  const { userRole } = useAuth();
  const { toast } = useToast();

  const generateDailyReport = async () => {
    try {
      // Get today's sales
      const today = new Date();
      const startOfToday = new Date(today.getFullYear(), today.getMonth(), today.getDate());
      const endOfToday = new Date(today.getFullYear(), today.getMonth(), today.getDate() + 1);

      let query = supabase
        .from('sales')
        .select(`
          *,
          profiles (full_name)
        `)
        .gte('created_at', startOfToday.toISOString())
        .lt('created_at', endOfToday.toISOString())
        .order('created_at', { ascending: false });

      const { data: sales, error } = await query;

      if (error) throw error;

      if (!sales || sales.length === 0) {
        toast({
          title: "No Data",
          description: "No sales found for today.",
          variant: "destructive",
        });
        return;
      }

      // Create PDF
      const doc = new jsPDF();
      
      // Add title
      doc.setFontSize(20);
      doc.text('NBS ST - Daily Sales Report', 20, 20);
      
      // Add date
      doc.setFontSize(12);
      doc.text(`Date: ${format(today, 'MMMM dd, yyyy')}`, 20, 35);
      
      // Calculate totals
      const totalAmount = sales.reduce((sum: number, sale: Sale) => sum + sale.amount, 0);
      const totalSales = sales.length;
      
      // Add summary
      doc.text(`Total Sales: ${totalSales}`, 20, 50);
      doc.text(`Total Amount: $${totalAmount.toFixed(2)}`, 20, 60);
      
      // Prepare table data
      const tableData = sales.map((sale: Sale) => [
        format(new Date(sale.created_at), 'HH:mm'),
        sale.customer_name,
        sale.product_service,
        `$${sale.amount.toFixed(2)}`,
        sale.profiles.full_name,
        sale.notes || '-'
      ]);

      // Add table
      autoTable(doc, {
        head: [['Time', 'Customer', 'Product/Service', 'Amount', 'Salesman', 'Notes']],
        body: tableData,
        startY: 75,
        styles: {
          fontSize: 8,
          cellPadding: 2,
        },
        headStyles: {
          fillColor: [34, 197, 94], // Green color
          textColor: [255, 255, 255],
        },
        alternateRowStyles: {
          fillColor: [248, 249, 250],
        },
      });

      // Add footer
      const pageCount = doc.getNumberOfPages();
      for (let i = 1; i <= pageCount; i++) {
        doc.setPage(i);
        doc.setFontSize(8);
        doc.text(
          `Generated on ${format(new Date(), 'MMMM dd, yyyy HH:mm')} - Page ${i} of ${pageCount}`,
          20,
          doc.internal.pageSize.height - 10
        );
      }

      // Save the PDF
      doc.save(`NBS-ST-Daily-Report-${format(today, 'yyyy-MM-dd')}.pdf`);

      toast({
        title: "Report Generated",
        description: "Daily sales report has been downloaded.",
      });

    } catch (error: any) {
      toast({
        title: "Error",
        description: "Failed to generate report",
        variant: "destructive",
      });
    }
  };

  // Only show to admins
  if (userRole !== 'admin') {
    return null;
  }

  return (
    <Button onClick={generateDailyReport} variant="outline">
      <Download className="h-4 w-4 mr-2" />
      Export Daily Report
    </Button>
  );
};

export default PDFExport;