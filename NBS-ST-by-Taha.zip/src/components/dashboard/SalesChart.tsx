import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';
import { format, subDays, startOfDay, endOfDay } from 'date-fns';

interface ChartData {
  date: string;
  amount: number;
  count: number;
}

const SalesChart: React.FC = () => {
  const { userRole, user } = useAuth();
  const [chartData, setChartData] = useState<ChartData[]>([]);
  const [chartType, setChartType] = useState<'line' | 'bar'>('line');
  const [timeRange, setTimeRange] = useState<'7days' | '30days' | '90days'>('7days');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchChartData();
  }, [timeRange, userRole, user]);

  const fetchChartData = async () => {
    setLoading(true);
    try {
      const days = timeRange === '7days' ? 7 : timeRange === '30days' ? 30 : 90;
      const startDate = subDays(new Date(), days);

      let query = supabase
        .from('sales')
        .select('amount, created_at')
        .gte('created_at', startDate.toISOString())
        .order('created_at', { ascending: true });

      // If salesman, filter to their sales only
      if (userRole === 'salesman' && user) {
        query = query.eq('salesman_id', user.id);
      }

      const { data: sales, error } = await query;

      if (error) throw error;

      // Group sales by date
      const salesByDate: { [key: string]: { amount: number; count: number } } = {};

      // Initialize all dates in range
      for (let i = 0; i < days; i++) {
        const date = format(subDays(new Date(), days - 1 - i), 'yyyy-MM-dd');
        salesByDate[date] = { amount: 0, count: 0 };
      }

      // Add actual sales data
      sales?.forEach(sale => {
        const date = format(new Date(sale.created_at), 'yyyy-MM-dd');
        if (salesByDate[date]) {
          salesByDate[date].amount += sale.amount;
          salesByDate[date].count += 1;
        }
      });

      // Convert to chart data
      const chartData: ChartData[] = Object.entries(salesByDate).map(([date, data]) => ({
        date: format(new Date(date), 'MMM dd'),
        amount: data.amount,
        count: data.count,
      }));

      setChartData(chartData);
    } catch (error) {
      console.error('Error fetching chart data:', error);
    } finally {
      setLoading(false);
    }
  };

  const ChartComponent = chartType === 'line' ? LineChart : BarChart;

  return (
    <Card>
      <CardHeader>
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <CardTitle>Sales Trends</CardTitle>
          <div className="flex gap-2">
            <Select value={timeRange} onValueChange={(value: '7days' | '30days' | '90days') => setTimeRange(value)}>
              <SelectTrigger className="w-[120px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="7days">7 Days</SelectItem>
                <SelectItem value="30days">30 Days</SelectItem>
                <SelectItem value="90days">90 Days</SelectItem>
              </SelectContent>
            </Select>
            <Select value={chartType} onValueChange={(value: 'line' | 'bar') => setChartType(value)}>
              <SelectTrigger className="w-[100px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="line">Line</SelectItem>
                <SelectItem value="bar">Bar</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {loading ? (
          <div className="h-[300px] flex items-center justify-center">
            <div className="animate-pulse">Loading chart...</div>
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={300}>
            <ChartComponent data={chartData}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
              <XAxis dataKey="date" className="text-muted-foreground" />
              <YAxis className="text-muted-foreground" />
              <Tooltip 
                contentStyle={{
                  backgroundColor: 'hsl(var(--card))',
                  border: '1px solid hsl(var(--border))',
                  borderRadius: '6px',
                  color: 'hsl(var(--card-foreground))'
                }}
                formatter={(value: number, name: string) => [
                  name === 'amount' ? `$${value.toFixed(2)}` : value,
                  name === 'amount' ? 'Sales Amount' : 'Sales Count'
                ]}
              />
              {chartType === 'line' ? (
                <Line 
                  dataKey="amount" 
                  stroke="hsl(var(--primary))" 
                  strokeWidth={2}
                />
              ) : (
                <Bar 
                  dataKey="amount" 
                  fill="hsl(var(--primary))"
                />
              )}
            </ChartComponent>
          </ResponsiveContainer>
        )}
      </CardContent>
    </Card>
  );
};

export default SalesChart;