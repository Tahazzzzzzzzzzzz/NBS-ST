import React from 'react';
import { Button } from '@/components/ui/button';
import { DollarSign, LogOut, User } from 'lucide-react';
import { useAuth } from '@/hooks/useAuth';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

const Header: React.FC = () => {
  const { profile, userRole, signOut } = useAuth();

  return (
    <header className="border-b border-border bg-card">
      <div className="flex h-16 items-center justify-between px-6">
        <div className="flex items-center">
          <DollarSign className="h-6 w-6 text-primary mr-2" />
          <h1 className="text-xl font-bold text-foreground">NBS ST</h1>
          {userRole && (
            <span className="ml-4 px-2 py-1 text-xs bg-primary text-primary-foreground rounded-full">
              {userRole.toUpperCase()}
            </span>
          )}
        </div>

        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="outline" size="sm">
              <User className="h-4 w-4 mr-2" />
              {profile?.full_name || 'User'}
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={signOut}>
              <LogOut className="h-4 w-4 mr-2" />
              Sign Out
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </header>
  );
};

export default Header;